package com.cre8web.photovault;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
